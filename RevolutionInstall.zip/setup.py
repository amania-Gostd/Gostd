import zipfile,os,time
bar_template = "\r[{0}] {1}/{2} 読み込み"
def prog(c):
    a = 100
    b = a+1
    for i in range(1,b):
        time.sleep(c)

        # []内の"#"と空白を調整する。iが1で#1つに空白29、iが30で#30個に空白0
        bar = "█" * i + " " * (b-i)
        print(bar_template.format(bar, i, a), end="")
def install():
    with zipfile.ZipFile('install.system') as existing_zip:
        existing_zip.extractall('Revolution/')
os.system("color 1f && title Revolution Instller")
print("""
RestOS V2 Installer
-------------------------------------------------------------------------------------
*****************************
* Install RestOS            *
*                           *
* > Setting Revolution      *
* Install RestSystem        *
* Setting User              *
* Apply UserSetting         *
* install update            *
* Final processing          *
*                           *
*****************************""")
prog(0.01)
os.system("cls")
print("""
RestOS V2 Installer
-------------------------------------------------------------------------------------
*****************************
* Install RestOS            *
*                           *
* Setting Revolution        *
* > Install RestSystem      *
* Setting User              *
* Apply UserSetting         *
* install update            *
* Final processing          *
*                           *
*****************************""")
install()
prog(0.1)
os.system("cls")
print("""
RestOS V2 Installer
-------------------------------------------------------------------------------------
*****************************
* Install RestOS            *
*                           *
* Setting Revolution        *
* Install RestSystem        *
* > Setting User            *
* Apply UserSetting         *
* install update            *
* Final processing          *
*                           *
*****************************""")
os.system("""cd Revolution && mkdir User && cd User && mkdir root""")
os.system("cls")
print("""
RestOS V2 Installer
-------------------------------------------------------------------------------------
*****************************
* Install RestOS            *
*                           *
* Setting Revolution        *
* Install RestSystem        *
* Setting User              *
* > Apply UserSetting       *
* install update            *
* Final processing          *
*                           *
*****************************""")
prog(0.1)
os.system("cls")
print("""
RestOS V2 Installer
-------------------------------------------------------------------------------------
*****************************
* Install RestOS            *
*                           *
* Setting Revolution        *
* Install RestSystem        *
* Setting User              *
* Apply UserSetting         *
* > install update          *
* Final processing          *
*                           *
*****************************""")
prog(0.2)
os.system("cls")
print("""
RestOS V2 Installer
-------------------------------------------------------------------------------------
*****************************
* Install RestOS            *
*                           *
* Setting Revolution        *
* Install RestSystem        *
* Setting User              *
* Apply UserSetting         *
* install update            *
* > Final processing        *
*                           *
*****************************""")
prog(0.1)
os.system("cls")
print("""
RestOS V2 Installer
-------------------------------------------------------------------------------------

Install Complited!!
""")
input()

